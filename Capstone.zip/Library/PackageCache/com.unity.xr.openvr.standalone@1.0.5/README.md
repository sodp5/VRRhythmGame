# OpenVR (Desktop) Package

The purpose of this package is to provide OpenVR XR Support. This package provides the necessary sdk libraries for users to build Applications that work with the SteamVR runtime.

## Package structure

```
<root>
	com.unity.openvr
		README
		Licenses
		CHANGELOG
		Documentation
		package.json
```
